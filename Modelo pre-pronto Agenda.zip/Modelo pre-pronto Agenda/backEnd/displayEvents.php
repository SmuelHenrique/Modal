<?php
    // Dentro dessa página os dados coletados serão transformados em Json.
        // Após isso serão passados ao calendário nesse formato
    use connection;

    class displayEvents extends connection {
        // Aqui será trazidos os dados
        public function getEvents(){ // Essa função trará todos os eventos presentes no banco de dados
        // Parece que deveremos, após coletar os dados, enviá-los para uma página que conterá apenas os arquivos JSON
            try {
                $b = $this->conexao()->prepare("SELECT * FROM events");
                $b->execute();
                $f = $b->fetchAll(\PDO::FETCH_ASSOC);
                return json_encode($f); // Após coletarmos os dados eles são transformados em Json
                    // Isso porque o calendário registra seu eventos em JSON
                    // Dentro do tutorial ele ainda passa um echo após a passagem de JSON
                        // Muito possivelmente para ter o modelo em String
            } catch (\PDOException $e) {
                return $e -> getMessage();
            }
        }
    }
?>