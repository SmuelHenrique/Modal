<!-- Conexão com o banco de dados -->
    <?php
        abstract class PHP{ // Aqui o professor/youtuber disse que deveria ser abstract para não ser instanciada
        // Todo esse bloco é a conexão com o banco de dados    
            public function conexao(){
                try {
                    $con = new \PDO("mysql:host="."HOST".";dbname="."DATABSE"."", "USER", "PASS"); // Aqui está a conexão com o banco de daos
                    return $con;
                    //Código da conexão que eu já devemos ter pronto em algum lugar
                } catch (\PDOException $e) {
                    return $e -> getMessage();
                }
            }
        // Aqui foi o fim da conexão com obanco de dados
        
        // Nesse momento criaremos diversas funções em PHP que permitam manipular o banco de dados
            // Pode-se dizer que semelhante ao modelo DAO
        
            public function getEvents(){ // Essa função trará todos os eventos presentes no banco de dados
            // Parece que deveremos, após coletar os dados, enviá-los para uma página que conterá apenas os arquivos JSON
                try {
                    $b = $this->conexao()->prepare("SELECT * FROM events");
                    $b->execute();
                    $f = $b->fetchAll(\PDO::FETCH_ASSOC);
                    return json_encode($f); // Após coletarmos os dados eles são transformados em Json
                        // Isso porque o calendário registra seu eventos em JSON
                        // Dentro do tutorial ele ainda passa um echo após a passagem de JSON
                            // Muito possivelmente para ter o modelo em String
                } catch (\PDOException $e) {
                    return $e -> getMessage();
                }
            }

            public function getEvent(int $id){
            // Aqui será a função para exibir um evento apenas
                // Pretendemos exibir essa função dentro da div do formulário
            }

            public function updateEvent(int $id){
            // Aqui será a função responsavél por atualizar o evento
                // Será possível saber se deve salvar ou atualizar quando abrir o modal
                    // O intuito é que ao clicar NO EVENTO ele chama ESTA FUNÇÃO
                    // Ao clicar EM UMA DATA ele chama a FUNÇÂO 'saveEvent'
            }

            public function saveEvent(){
            // Aqui será a função que apenas salva um evento
            }

            public function deleteEvent(int $id){
            // Aqui será a função responsavél por excluir os eventos
            }

        }
    ?>